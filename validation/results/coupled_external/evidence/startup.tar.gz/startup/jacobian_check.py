import numpy as np, sys
pre=sys.argv[1]; alpha=float(sys.argv[2])
geo=np.fromfile('runs/dump/geom.bin',dtype=np.float32).reshape(-1,5); n=len(geo)
def load(k):
    a=np.fromfile(f'{pre}_{k}.bin',dtype=np.float32)
    return a[:4*n].reshape(4,n), a[4*n:8*n].reshape(4,n), a[8*n:28*n].reshape(20,n), a[28*n:].reshape(3,n)
b0,x0,c0,e0=load(0); b1,_,_,_=load(1)
for k,name in [(0,'u'),(1,'v'),(3,'p')]:
    actual=b0[k]-b1[k]; pred=alpha*b0[k]
    print(f"{name}: |b0|={np.linalg.norm(b0[k]):.3e} |actual|={np.linalg.norm(actual):.3e} |pred|={np.linalg.norm(pred):.3e} |err|={np.linalg.norm(actual-pred):.3e}")
big=np.argsort(-np.hypot(x0[0],x0[1]))[:8]
print("largest updates:")
for i in big:
    print(f"  {i} ({geo[i,0]:.4f},{geo[i,1]:.4f}) f={int(geo[i,3])} du=({x0[0,i]:.3f},{x0[1,i]:.3f}) dp={x0[3,i]:.3e} D={c0[0,i]:.2e} off={e0[0,i]:.2e} net={e0[1,i]:.2e} b=({b0[0,i]:.2e},{b0[1,i]:.2e},{b0[3,i]:.2e})")
for k,name in [(0,'u'),(3,'p')]:
    err=(b0[k]-b1[k])-alpha*b0[k]; idx=np.argsort(-np.abs(err))[:6]
    print(name,"worst mismatch:")
    for i in idx:
        print(f"  {i} ({geo[i,0]:.4f},{geo[i,1]:.4f}) f={int(geo[i,3])} b0={b0[k,i]:.2e} actual={b0[k,i]-b1[k,i]:.2e} pred={alpha*b0[k,i]:.2e} du=({x0[0,i]:.3f},{x0[1,i]:.3f}) dp={x0[3,i]:.2e} D={c0[0,i]:.2e} off={e0[0,i]:.2e}")
