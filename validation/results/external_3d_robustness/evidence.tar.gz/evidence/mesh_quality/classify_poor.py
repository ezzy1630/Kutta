import csv,math,collections,sys
L,W,H,CL,SL=1.044,0.389,0.288,0.05,0.222
xs=-SL*math.cos(math.radians(35)); top=CL+H
def roof_z(x): return top if x<xs else top-(x-xs)*math.tan(math.radians(35))
for path in sys.argv[1:]:
    rows=list(csv.DictReader(open(path))); c=collections.Counter(); t=0.02
    for r in rows:
        x,y,z=float(r['x']),float(r['y']),float(r['z']); ay=abs(y)
        if abs(x)<t: k="base perimeter edges (x=0)"
        elif abs(ay-W/2)<t and abs(z-CL)<t: k="lower longitudinal edges"
        elif abs(ay-W/2)<t and abs(z-roof_z(x))<t: k="upper longitudinal and slant side edges"
        elif abs(x-xs)<t and abs(z-top)<t: k="roof-slant edge"
        else: k="elsewhere"
        c[k]+=1
    print(path.split('/')[-1], len(rows), dict(c.most_common()))
