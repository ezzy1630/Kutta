| slant | scheme | level | cells | flagged cells | iterations | solve s | peak GB | Cd | Cd range, last 2000 | vs 0.26 | friction Cd | front / slant / base pressure Cd | CL | max residual | raw continuity | stop | y+ mean / max |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 25 | Coupled | L2 | 762,644 | 1,227 | 5000 | 1470 | 3.68 | 0.3221 | 0.3211-0.3228 | +23.9% | 0.045 | -0.005 / 0.116 / 0.137 | 0.278 | 1.5e-02 | 4.8e-03 | not converged | 0.85 / 1.64 |
| 25 | SIMPLEC | L2 | 762,644 | 1,227 | 2850 | 1482 | 3.14 | 0.3182 | 0.3175-0.3183 | +22.4% | 0.045 | -0.006 / 0.113 / 0.137 | 0.264 | 4.1e-06 | 4.8e-04 | converged | 0.85 / 1.65 |
| 35 | Coupled | L1 | 446,128 | 2,127 | 5000 | 553 | 2.13 | 0.3548 | 0.3545-0.3551 | +36.4% | 0.044 | -0.004 / 0.186 / 0.129 | 0.223 | 4.7e-03 | 1.5e-03 | not converged | 0.88 / 1.64 |
| 35 | Coupled | L2 | 757,796 | 1,262 | 5000 | 1263 | 3.67 | 0.3288 | 0.3285-0.3290 | +26.5% | 0.044 | -0.005 / 0.163 / 0.127 | 0.141 | 5.1e-03 | 1.6e-03 | not converged | 0.84 / 1.64 |
| 35 | Coupled | L3 | 1,444,908 | 139 | 5000 | 1490 | 6.78 | 0.3094 | 0.3093-0.3094 | +19.0% | 0.045 | -0.007 / 0.149 / 0.123 | 0.086 | 3.5e-03 | 1.1e-03 | not converged | 0.82 / 1.66 |
| 35 | Coupled | L3.5 | 2,108,192 | 42 | 5000 | 2461 | 9.36 | 0.3031 | 0.3030-0.3031 | +16.6% | 0.046 | -0.008 / 0.144 / 0.121 | 0.071 | 2.2e-03 | 6.7e-04 | not converged | 0.83 / 1.70 |
| 35 | SIMPLEC | L1 | 446,128 | 2,127 | 5000 | 632 | 1.80 | 0.3545 | 0.3545-0.3546 | +36.4% | 0.044 | -0.004 / 0.185 / 0.129 | 0.220 | 5.1e-06 | 3.6e-04 | residuals met, forces drifting | 0.88 / 1.65 |
| 35 | SIMPLEC | L2 | 757,796 | 1,262 | 5000 | 1614 | 3.13 | 0.3326 | 0.3272-0.3383 | +27.9% | 0.044 | -0.005 / 0.163 / 0.137 | 0.146 | 7.5e-03 | 1.9e-02 | not converged | 0.84 / 1.64 |
| 35 | SIMPLEC | L3 | 1,444,908 | 139 | 5000 | 1382 | 5.73 | 0.3144 | 0.3109-0.3175 | +20.9% | 0.045 | -0.008 / 0.151 / 0.129 | 0.090 | 6.2e-03 | 1.7e-02 | not converged | 0.82 / 1.66 |
| 35 | SIMPLEC | L3.5 | 2,108,192 | 42 | 5000 | 2075 | 7.93 | 0.3031 | 0.3028-0.3036 | +16.6% | 0.046 | -0.008 / 0.144 / 0.121 | 0.070 | 6.2e-04 | 2.4e-03 | residuals met, forces drifting | 0.83 / 1.70 |

| slant | scheme | level | centreline stations -203 -163 -123 -83 -43 -3 mm | reversed slant area |
| --- | --- | --- | --- | --- |
| 25 | Coupled | L2 | A R R R R R | 0.57 |
| 25 | SIMPLEC | L2 | A R R R R A | 0.64 |
| 35 | Coupled | L1 | - R R R R R | 0.85 |
| 35 | Coupled | L2 | - R R R R A | 0.87 |
| 35 | Coupled | L3 | - R R R R A | 0.88 |
| 35 | Coupled | L3.5 | - R R R R A | 0.89 |
| 35 | SIMPLEC | L1 | - R R R R R | 0.86 |
| 35 | SIMPLEC | L2 | - R R R R A | 0.87 |
| 35 | SIMPLEC | L3 | - R R R R A | 0.88 |
| 35 | SIMPLEC | L3.5 | - R R R R A | 0.89 |

| slant | scheme | level | reference | region | taps | reference mean Cp | Kutta mean Cp | RMS difference |
| --- | --- | --- | --- | --- | ---: | ---: | ---: | ---: |
| 25 | Coupled | L2 | experiment | slant | 166 | -0.556 | -0.467 | 0.221 |
| 25 | Coupled | L2 | experiment | base | 102 | -0.174 | -0.235 | 0.142 |
| 25 | Coupled | L2 | CFX-5 SST | slant | 970 | -0.320 | -0.465 | 0.249 |
| 25 | Coupled | L2 | CFX-5 SST | base | 1076 | -0.175 | -0.252 | 0.162 |
| 25 | SIMPLEC | L2 | experiment | slant | 166 | -0.556 | -0.460 | 0.222 |
| 25 | SIMPLEC | L2 | experiment | base | 102 | -0.174 | -0.241 | 0.148 |
| 25 | SIMPLEC | L2 | CFX-5 SST | slant | 970 | -0.320 | -0.453 | 0.236 |
| 25 | SIMPLEC | L2 | CFX-5 SST | base | 1076 | -0.175 | -0.242 | 0.151 |
| 35 | Coupled | L1 | experiment | slant | 122 | -0.270 | -0.403 | 0.267 |
| 35 | Coupled | L1 | experiment | base | 69 | -0.219 | -0.279 | 0.169 |
| 35 | Coupled | L1 | CFX-5 SST | slant | 630 | -0.234 | -0.459 | 0.315 |
| 35 | Coupled | L1 | CFX-5 SST | base | 573 | -0.167 | -0.276 | 0.184 |
| 35 | Coupled | L2 | experiment | slant | 171 | -0.266 | -0.346 | 0.190 |
| 35 | Coupled | L2 | experiment | base | 97 | -0.220 | -0.252 | 0.112 |
| 35 | Coupled | L2 | CFX-5 SST | slant | 1007 | -0.233 | -0.386 | 0.216 |
| 35 | Coupled | L2 | CFX-5 SST | base | 933 | -0.172 | -0.265 | 0.155 |
| 35 | Coupled | L3 | experiment | slant | 188 | -0.266 | -0.310 | 0.123 |
| 35 | Coupled | L3 | experiment | base | 99 | -0.220 | -0.231 | 0.073 |
| 35 | Coupled | L3 | CFX-5 SST | slant | 1106 | -0.233 | -0.339 | 0.140 |
| 35 | Coupled | L3 | CFX-5 SST | base | 1038 | -0.173 | -0.257 | 0.137 |
| 35 | Coupled | L3.5 | experiment | slant | 188 | -0.266 | -0.300 | 0.109 |
| 35 | Coupled | L3.5 | experiment | base | 99 | -0.220 | -0.216 | 0.043 |
| 35 | Coupled | L3.5 | CFX-5 SST | slant | 1110 | -0.233 | -0.322 | 0.107 |
| 35 | Coupled | L3.5 | CFX-5 SST | base | 1041 | -0.173 | -0.256 | 0.128 |
| 35 | SIMPLEC | L1 | experiment | slant | 122 | -0.270 | -0.402 | 0.266 |
| 35 | SIMPLEC | L1 | experiment | base | 69 | -0.219 | -0.279 | 0.171 |
| 35 | SIMPLEC | L1 | CFX-5 SST | slant | 630 | -0.234 | -0.457 | 0.312 |
| 35 | SIMPLEC | L1 | CFX-5 SST | base | 573 | -0.167 | -0.277 | 0.187 |
| 35 | SIMPLEC | L2 | experiment | slant | 171 | -0.266 | -0.345 | 0.193 |
| 35 | SIMPLEC | L2 | experiment | base | 97 | -0.220 | -0.266 | 0.122 |
| 35 | SIMPLEC | L2 | CFX-5 SST | slant | 1007 | -0.233 | -0.386 | 0.218 |
| 35 | SIMPLEC | L2 | CFX-5 SST | base | 933 | -0.172 | -0.281 | 0.171 |
| 35 | SIMPLEC | L3 | experiment | slant | 188 | -0.266 | -0.315 | 0.128 |
| 35 | SIMPLEC | L3 | experiment | base | 99 | -0.220 | -0.241 | 0.078 |
| 35 | SIMPLEC | L3 | CFX-5 SST | slant | 1106 | -0.233 | -0.345 | 0.145 |
| 35 | SIMPLEC | L3 | CFX-5 SST | base | 1038 | -0.173 | -0.269 | 0.146 |
| 35 | SIMPLEC | L3.5 | experiment | slant | 188 | -0.266 | -0.300 | 0.109 |
| 35 | SIMPLEC | L3.5 | experiment | base | 99 | -0.220 | -0.216 | 0.042 |
| 35 | SIMPLEC | L3.5 | CFX-5 SST | slant | 1110 | -0.233 | -0.322 | 0.107 |
| 35 | SIMPLEC | L3.5 | CFX-5 SST | base | 1041 | -0.173 | -0.256 | 0.128 |
