import csv, math, sys
path=sys.argv[1]; k=int(sys.argv[2]) if len(sys.argv)>2 else 10
rows=list(csv.DictReader(open(path)))
for r in rows: r['s']=math.sqrt(float(r['u'])**2+float(r['v'])**2+float(r['w'])**2)
rows.sort(key=lambda r:-r['s'])
print(path, "cells>3U:", sum(1 for r in rows if r['s']>3))
for r in rows[:k]: print("  x=%.4f y=%.4f z=%.4f vol=%.2e u=(%.1f,%.1f,%.1f) p=%.2f k=%.3g om=%.3g mut=%.3g"%(float(r['x']),float(r['y']),float(r['z']),float(r['volume']),float(r['u']),float(r['v']),float(r['w']),float(r['p']),float(r['k']),float(r['omega']),float(r['mu_t'])))
