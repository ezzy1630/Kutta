import csv, math, sys
path=sys.argv[1]; k=int(sys.argv[2]); key=sys.argv[3] if len(sys.argv)>3 else 's'
rows=list(csv.DictReader(open(path)))
for r in rows:
  r['s']=math.sqrt(float(r['u'])**2+float(r['v'])**2+float(r['w'])**2); r['ap']=abs(float(r['p']))
rows.sort(key=lambda r:-r[key])
print(path, key)
for r in rows[:k]: print("  x=%.4f y=%.4f z=%.4f vol=%.2e u=(%.2f,%.2f,%.2f) p=%.3f k=%.3g om=%.3g"%(float(r['x']),float(r['y']),float(r['z']),float(r['volume']),float(r['u']),float(r['v']),float(r['w']),float(r['p']),float(r['k']),float(r['omega'])))
