// SCRATCH (not committed): per-cell mesh quality near probe points.
#include <algorithm>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <iostream>
#include <sstream>
#include <vector>

#include "kutta/io/mesh_io.hpp"
#include "kutta/mesh/mesh.hpp"
#include "kutta/mesh/topology.hpp"
#include "kutta/mesh/detail.hpp"

using namespace kutta;
using namespace kutta::detail;
static double dotp(Vec3d a, Vec3d b) { return a.x * b.x + a.y * b.y + a.z * b.z; }
static double nrm(Vec3d a) { return std::sqrt(dotp(a, a)); }

int main(int argc, char** argv) {
  std::string in = argv[1];
  auto mesh = in.ends_with(".p2dfmt") ? read_plot3d(in, .01) : read_fluent_msh(in);
  auto g = compute_geometry(mesh);
  auto cf = build_cell_faces(mesh);
  const Index n = mesh.n_cells, ni = mesh.n_internal_faces();
  std::vector<int> wall(n, 0);
  for (auto& p : mesh.patches)
    if (p.name == "body")
      for (Index f = p.start; f < p.start + p.size; ++f) wall[mesh.owner[f]] = 1;
  struct Q { double ortho, skew, aspect, cond, minh; };
  std::vector<Q> q(n);
  for (Index c = 0; c < n; ++c) {
    double a[3][3]{};
    Q r{0, 0, 0, 0, 1e30};
    double rmin = 1e30, rmax = 0;
    for (Index j = cf.offsets[c]; j < cf.offsets[c + 1]; ++j) {
      Index f = cf.faces[j];
      Vec3d S = g.face_area[f] * double(cf.signs[j]);
      Vec3d d = f < ni ? g.cell_centroid[mesh.owner[f] == c ? mesh.neighbour[f] : mesh.owner[f]] - g.cell_centroid[c]
                       : g.face_centroid[f] - g.cell_centroid[c];
      double ang = std::acos(std::clamp(dotp(S, d) / (nrm(S) * nrm(d)), -1., 1.)) * 180 / M_PI;
      r.ortho = std::max(r.ortho, ang);
      if (f < ni) {
        // where P->N crosses the face plane
        double t = dotp(S, g.face_centroid[f] - g.cell_centroid[c]) / dotp(S, d);
        Vec3d x = g.cell_centroid[c] + d * t;
        r.skew = std::max(r.skew, nrm(x - g.face_centroid[f]) / nrm(d));
      }
      Vec3d rf = g.face_centroid[f] - g.cell_centroid[c];
      double h = std::abs(dotp(rf, S)) / nrm(S);
      rmin = std::min(rmin, h);
      rmax = std::max(rmax, nrm(rf));
      double w = 1 / dotp(d, d);
      double dv[3]{d.x, d.y, d.z};
      for (int u = 0; u < 3; ++u)
        for (int v = 0; v < 3; ++v) a[u][v] += w * dv[u] * dv[v];
    }
    r.aspect = rmax / rmin;
    r.minh = rmin;
    // eigenvalues of symmetric 3x3 (Jacobi sweeps)
    double m[3][3];
    for (int u = 0; u < 3; ++u)
      for (int v = 0; v < 3; ++v) m[u][v] = a[u][v];
    for (int it = 0; it < 50; ++it)
      for (int p = 0; p < 3; ++p)
        for (int qq = p + 1; qq < 3; ++qq) {
          if (std::abs(m[p][qq]) < 1e-300) continue;
          double th = 0.5 * std::atan2(2 * m[p][qq], m[qq][qq] - m[p][p]);
          double cs = std::cos(th), sn = std::sin(th);
          for (int k = 0; k < 3; ++k) {
            double mp = m[k][p], mq = m[k][qq];
            m[k][p] = cs * mp - sn * mq;
            m[k][qq] = sn * mp + cs * mq;
          }
          for (int k = 0; k < 3; ++k) {
            double mp = m[p][k], mq = m[qq][k];
            m[p][k] = cs * mp - sn * mq;
            m[qq][k] = sn * mp + cs * mq;
          }
        }
    double e0 = std::min({m[0][0], m[1][1], m[2][2]}), e1 = std::max({m[0][0], m[1][1], m[2][2]});
    r.cond = e0 / e1;
    q[c] = r;
  }
  if (const char* e = std::getenv("KUTTA_DUMP_CELL")) {
    std::istringstream in(e);
    for (Index c; in >> c;) {
      auto x = g.cell_centroid[c];
      std::printf("cell %d centroid (%.6f,%.6f,%.6f) vol %.3e\n", c, x.x, x.y, x.z, g.cell_volume[c]);
      for (Index j = cf.offsets[c]; j < cf.offsets[c + 1]; ++j) {
        Index f = cf.faces[j];
        Vec3d S = g.face_area[f] * double(cf.signs[j]);
        Index other = f < ni ? (mesh.owner[f] == c ? mesh.neighbour[f] : mesh.owner[f]) : -1;
        Vec3d d = other >= 0 ? g.cell_centroid[other] - g.cell_centroid[c] : g.face_centroid[f] - g.cell_centroid[c];
        Vec3d rf = g.face_centroid[f] - g.cell_centroid[c];
        double ang = std::acos(std::clamp(dotp(S, d) / (nrm(S) * nrm(d)), -1., 1.)) * 180 / M_PI;
        std::printf("  f=%d nb=%d |S|=%.3e n=(%.3f,%.3f,%.3f) |d|=%.3e d=(%.2e,%.2e,%.2e) rf=(%.2e,%.2e,%.2e) ang=%.1f nodes:", f, other, nrm(S),
                    S.x / nrm(S), S.y / nrm(S), S.z / nrm(S), nrm(d), d.x, d.y, d.z, rf.x, rf.y, rf.z, ang);
        for (Index k = mesh.face_offsets[f]; k < mesh.face_offsets[f + 1]; ++k) {
          auto pt = mesh.points[mesh.face_nodes[k]];
          std::printf(" (%.6f,%.6f,%.6f)", pt.x, pt.y, pt.z);
        }
        std::printf("\n");
      }
    }
  }
  if (const char* out = std::getenv("KUTTA_POOR_OUT")) {
    const auto oq = orthogonal_quality(mesh, g);
    std::FILE* o = std::fopen(out, "w");
    std::fprintf(o, "x,y,z,oq,wall\n");
    for (Index c = 0; c < n; ++c)
      if (oq[c] <= 0.05) std::fprintf(o, "%.6f,%.6f,%.6f,%.5f,%d\n", g.cell_centroid[c].x, g.cell_centroid[c].y, g.cell_centroid[c].z, oq[c], wall[c]);
    std::fclose(o);
  }
  if (std::getenv("KUTTA_POOR_COUNT")) {
    const auto oq = orthogonal_quality(mesh, g);
    Index k = 0; double lo = 1;
    for (Index c = 0; c < n; ++c) { lo = std::min(lo, oq[c]); if (oq[c] <= 0.05) { if (k < 8) std::printf("poor %d (%.5f,%.5f) oq %.4f\n", c, g.cell_centroid[c].x, g.cell_centroid[c].y, oq[c]); ++k; } }
    std::printf("cells %d poor %d min oq %.4f\n", n, k, lo);
    return 0;
  }
  auto stats = [&](const char* name, auto pick, bool walls) {
    std::vector<double> v;
    for (Index c = 0; c < n; ++c)
      if (!walls || wall[c]) v.push_back(pick(q[c]));
    std::sort(v.begin(), v.end());
    auto at = [&](double p) { return v[std::min<size_t>(v.size() - 1, size_t(p * v.size()))]; };
    std::printf("%-8s %s n=%zu p50=%.4g p90=%.4g p99=%.4g p999=%.4g max=%.4g min=%.4g\n", name, walls ? "wall" : "all ", v.size(),
                at(.5), at(.9), at(.99), at(.999), v.back(), v.front());
  };
  for (bool w : {false, true}) {
    stats("ortho", [](const Q& r) { return r.ortho; }, w);
    stats("skew", [](const Q& r) { return r.skew; }, w);
    stats("aspect", [](const Q& r) { return r.aspect; }, w);
    stats("cond", [](const Q& r) { return r.cond; }, w);
  }
  for (int a = 2; a + 2 < argc + 1 && a + 2 <= argc - 1; a += 3) {
    Vec3d p{std::stod(argv[a]), std::stod(argv[a + 1]), std::stod(argv[a + 2])};
    std::vector<Index> idx(n);
    for (Index c = 0; c < n; ++c) idx[c] = c;
    std::partial_sort(idx.begin(), idx.begin() + 6, idx.end(),
                      [&](Index x, Index y) { return nrm(g.cell_centroid[x] - p) < nrm(g.cell_centroid[y] - p); });
    std::printf("near (%g,%g,%g):\n", p.x, p.y, p.z);
    for (int k = 0; k < 6; ++k) {
      Index c = idx[k];
      auto x = g.cell_centroid[c];
      std::printf("  c=%d (%.5f,%.5f,%.5f) wall=%d vol=%.3e ortho=%.1f skew=%.3f aspect=%.0f cond=%.2e minh=%.2e nf=%d\n", c, x.x, x.y,
                  x.z, wall[c], g.cell_volume[c], q[c].ortho, q[c].skew, q[c].aspect, q[c].cond, q[c].minh,
                  int(cf.offsets[c + 1] - cf.offsets[c]));
    }
  }
}
// dump: KUTTA_DUMP_CELL=<id>
struct DumpAtExit {
  ~DumpAtExit() {}
};
