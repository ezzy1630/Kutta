#!/bin/bash
# usage: wing.sh <bench> <mesh> <out> [extra args...]
bench=$1; mesh=$2; out=$3; shift 3
/usr/bin/time -l "$bench" --mesh "$mesh" --re 4.62e5 --downforce --moving-ground --tu 0.001 --ratio 1 --settle -1 --out "$out" "$@" > "$out.log" 2>&1
