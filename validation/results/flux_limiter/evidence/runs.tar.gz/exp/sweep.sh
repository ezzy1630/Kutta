#!/bin/bash
# usage: sweep.sh <bench> <outdir> [extra args...]; 7 cases in parallel, as the plateau report's fsae2d.sh
bench=$1; out=$2; shift 2; mkdir -p $out
M=runs/fsae_aero/mesh
run() { name=$1; mesh=$2; shift 2; /usr/bin/time -l "$bench" --mesh $M/$mesh --out $out/$name --iterations 3000 --max-seconds 3600 "$@" > $out/$name.log 2>&1; }
W="--re 4.62e5 --downforce --tu 0.001 --ratio 1"
run free zerihan_hfree_L2.msh $W "$@" &
run h0.448 zerihan_h0.448_L2.msh $W --moving-ground "$@" &
run h0.224 zerihan_h0.224_L2.msh $W --moving-ground "$@" &
run h0.134 zerihan_h0.134_L2.msh $W --moving-ground "$@" &
run h0.090 zerihan_h0.090_L2.msh $W --moving-ground "$@" &
run s4.76 s1223_a4.76_L2.msh --re 2e5 --tu 0.001 --ratio 1 "$@" &
run s10 s1223_a10.00_L2.msh --re 2e5 --tu 0.001 --ratio 1 "$@" &
wait
