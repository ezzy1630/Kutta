#!/bin/bash
# usage: ahmed.sh <bench> <mesh> <out> [extra args...]
bench=$1; mesh=$2; out=$3; shift 3
/usr/bin/time -l "$bench" --mesh "$mesh" --re 2.78e6 --length 1.044 --area 0.112 --walls body --lift-z --tu 0.01 --window 1000 --settle -1 --out "$out" "$@" > "$out.log" 2>&1
