"""Compare two kutta solve output dirs: byte-identical files, residuals.csv minus its timing column."""
import sys, os, csv, hashlib, json
a, b = sys.argv[1], sys.argv[2]
def h(p): return hashlib.sha256(open(p, 'rb').read()).hexdigest()
ok = True
for f in ("fluxes.csv", "forces.csv", "loads.json", "result.vtu"):
    pa, pb = os.path.join(a, f), os.path.join(b, f)
    if not os.path.exists(pa): continue
    if f == "result.vtu":
        # drop the provenance header comment lines
        la = [l for l in open(pa) if not l.startswith("<!--")]
        lb = [l for l in open(pb) if not l.startswith("<!--")]
        same = la == lb
    elif f == "loads.json":
        ja, jb = json.load(open(pa)), json.load(open(pb))
        for j in (ja, jb):
            for k in list(j):
                if k in ("summary", "provenance", "build", "timing"): j.pop(k)
        same = ja == jb
    else:
        same = h(pa) == h(pb)
    print(f"{f:14s} {'identical' if same else 'DIFFERENT'}"); ok &= same
ra = list(csv.reader(open(os.path.join(a, "residuals.csv"))))
rb = list(csv.reader(open(os.path.join(b, "residuals.csv"))))
hdr = next(r for r in ra if r and r[0] == "iteration"); drop = [i for i, c in enumerate(hdr) if "sec" in c or "time" in c]
strip = lambda rows: [[x for i, x in enumerate(r) if i not in drop] for r in rows]
same = strip(ra) == strip(rb)
print(f"residuals.csv  {'identical' if same else 'DIFFERENT'} (dropped columns {[hdr[i] for i in drop]})"); ok &= same
sys.exit(0 if ok else 1)
