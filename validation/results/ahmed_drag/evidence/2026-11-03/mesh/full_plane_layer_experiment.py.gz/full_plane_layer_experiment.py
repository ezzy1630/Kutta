import hashlib,json,pathlib,sys
import numpy as np
from scipy.spatial import cKDTree
root=pathlib.Path(__file__).resolve().parents[2];sys.path.insert(0,str(root/'tools/fsae_aero'))
import ahmed,fluent_msh
base=root/'runs/ahmed_cause';state={};old_layers=ahmed.layers;old_subdivide=ahmed.subdivide.subdivide

def plane_offsets(p,tri):
 raw=np.cross(p[tri[:,1]]-p[tri[:,0]],p[tri[:,2]]-p[tri[:,0]])
 area=np.linalg.norm(raw,axis=1);unit=raw/area[:,None]
 matrix=np.zeros((len(p),3,3));rhs=np.zeros_like(p)
 terms=area[:,None,None]*unit[:,:,None]*unit[:,None,:]
 for j in range(3):
  np.add.at(matrix,tri[:,j],terms);np.add.at(rhs,tri[:,j],raw)
 values,vectors=np.linalg.eigh(matrix);projected=np.einsum('nji,nj->ni',vectors,rhs)
 scaled=np.divide(projected,values,out=np.zeros_like(projected),where=values>values[:,-1,None]*1e-12)
 direction=np.einsum('nij,nj->ni',vectors,scaled)
 projection=np.einsum('fki,fi->fk',direction[tri],unit)
 if np.any(projection<=0) or not np.isfinite(direction).all():raise ValueError('invalid plane offset direction')
 return direction

def capture(p,tri,top,first,growth=1.35):
 shells,total=old_layers(p,tri,top,first,growth);raw=[p.copy()];height=[0.];step=first
 for j in range(len(shells)-1):
  raw.append(raw[-1]+step*plane_offsets(raw[-1],tri));height.append(height[-1]+step);step*=growth
 weight=(1-np.array(height)/height[-1])**2
 balanced=np.array(raw);balanced[0]=shells[0]
 state.update(old=shells,new=balanced,tri=tri,first=first,total=total)
 return shells,total

def alter(points,tets,prisms,boundary):
 count=state['old'][:-1].size//3;copy=points.copy();assert np.array_equal(copy[-count:],state['old'][:-1].reshape(-1,3))
 distance,cap=cKDTree(copy[:-count]).query(state['old'][-1]);assert distance.max()<1e-12 and len(np.unique(cap))==len(cap)
 copy[cap]=state['new'][-1]
 copy[-count:]=state['new'][:-1].reshape(-1,3)
 oldp,oldh,oldb=old_subdivide(points,tets,prisms,boundary)
 newp,newh,newb=old_subdivide(copy,tets,prisms,boundary)
 assert np.array_equal(oldh,newh)
 for (a,b,c),(d,e,f) in zip(oldb,newb):assert (a,b)==(d,e) and np.array_equal(c,f)
 changed=np.any(oldp!=newp,axis=1);outside_changed=np.any(changed[oldh[:4*len(tets)]],axis=1)
 for name,kind,faces in oldb:assert np.array_equal(oldp[np.unique(faces)],newp[np.unique(faces)]),name
 body=np.unique(next(f for name,kind,f in oldb if name=='body'));assert np.array_equal(oldp[body],newp[body])
 replay=base/'mesh/full_plane_layer_baseline_replay.msh';fluent_msh.write(replay,oldp,[(5,oldh)],oldb,comment='fsae_aero ahmed 35.0')
 baseline=base/'mesh/compact_L1.msh';digest=hashlib.sha256(replay.read_bytes()).hexdigest();assert digest==hashlib.sha256(baseline.read_bytes()).hexdigest();replay.unlink()
 p=state['old'][0];tri=state['tri'];normal=np.cross(p[tri[:,1]]-p[tri[:,0]],p[tri[:,2]]-p[tri[:,0]]);normal/=np.linalg.norm(normal,axis=1)[:,None]
 leading=(p[tri].mean(axis=1)[:,0]>-.222*np.cos(np.radians(35)))&(p[tri].mean(axis=1)[:,0]<-.222*np.cos(np.radians(35))+.04)&(normal[:,0]>.3)&(normal[:,2]>.3)
 diagnostics={}
 for name,shell in [('unit',state['old']),('plane_full_stack',state['new'])]:
  h=np.einsum('fki,fi->fk',(shell[1]-shell[0])[tri],normal)/state['first']
  diagnostics[name]={'leading_triangles':int(leading.sum()),'leading_relative_normal_height_quantiles':np.quantile(h[leading],[0,.5,1]).tolist(),'leading_max_within_triangle_height_spread':float(np.ptp(h[leading],axis=1).max())}
 proof={'baseline_replay_sha256':digest,'cells':len(newh),'points':len(newp),'outer_volume_hexes_unchanged':int((~outside_changed).sum()),'outer_volume_hexes_changed':int(outside_changed.sum()),'boundary_points_bit_identical':True,'wall_points_bit_identical':True,'cell_and_boundary_connectivity_bit_identical':True,'max_point_displacement':float(np.linalg.norm(newp-oldp,axis=1).max()),'blend':'none; complete plane-offset stack and shared cap nodes moved on unchanged connectivity','diagnostics':diagnostics}
 (base/'mesh/full_plane_layer_identity.json').write_text(json.dumps(proof,indent=2)+'\n');print(json.dumps(proof),flush=True)
 return newp,newh,newb

ahmed.layers=capture;ahmed.subdivide.subdivide=alter
out=base/'mesh/full_plane_layer_L1.msh'
meta=ahmed.build(35.0,1.0,out,first=1.5e-5,refinement_reach=.6,wake_padding=.3)
meta['experimental_layer_offset']='least-squares plane offsets across entire stack; cap and incident outer-volume points moved with unchanged connectivity'
pathlib.Path(str(out)+'.json').write_text(json.dumps(meta,indent=2)+'\n')
