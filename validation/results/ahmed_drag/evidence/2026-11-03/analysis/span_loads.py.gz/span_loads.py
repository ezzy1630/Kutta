"""Own wall loads clipped in x and y; no reference data."""
import json,pathlib,sys
import numpy as np
from scipy.spatial import cKDTree
root=pathlib.Path(__file__).resolve().parents[2];sys.path.insert(0,str(root/'tools/ahmed_drag'));import mesh_bands
report=mesh_bands.report;b=root/'runs/ahmed_cause';W=.389;phi=np.radians(35);xs=-.222*np.cos(phi)
def clip(p,axis,cut,left=True):
 out=[]
 for a,z in zip(p,np.roll(p,-1,axis=0)):
  ia=a[axis]<=cut if left else a[axis]>=cut;iz=z[axis]<=cut if left else z[axis]>=cut
  if ia:out.append(a)
  if ia!=iz:out.append(a+(z-a)*((cut-a[axis])/(z[axis]-a[axis])))
 return np.array(out).reshape(-1,3)
def area(p):
 return 0. if len(p)<3 else mesh_bands.polygon_geometry(p)[0]
def strip(p,lo,hi):
 return clip(clip(p,1,lo,False),1,hi,True)
names=['pressure_urf05_L1','edge10_L1','edge5_L1','plane_layer_L1','differentiable_L1','shear15_L1_pressure05','shear10_L1_pressure05','wake20_L1_pressure05','shear15_wake25_L1_pressure05'];rows=[]
for name in names:
 path=b/name;r=json.loads((path/'result.json').read_text());assert not r['result']['failure']
 walls=report.walls(path);walls=walls[report.regions(walls,35)['slant']];tree=cKDTree(np.column_stack([walls[k] for k in ['x','y','z']]))
 cmd=r['command'];mesh=root/cmd[cmd.index('--mesh')+1];aref=float(cmd[cmd.index('--area')+1]);q={}
 for p in mesh_bands.body_polygons(mesh):
  if np.max(np.abs(p[:,2]-(.338-(p[:,0]-xs)*np.tan(phi))))>1e-8:continue
  a,c=mesh_bands.polygon_geometry(p);distance,j=tree.query(c);assert distance<1e-8
  f=walls['cp'][j]*walls['nx'][j]/aref;lead=clip(p,0,xs+.04)
  parts={'whole':p,'leading':lead,'left':clip(p,1,0),'right':clip(p,1,0,False),'leading_left':clip(lead,1,0),'leading_right':clip(lead,1,0,False)}
  parts['leading_centre']=strip(lead,-W/6,W/6)
  parts['leading_middle_left']=strip(lead,-W/3,-W/6);parts['leading_middle_right']=strip(lead,W/6,W/3)
  parts['leading_outer_left']=strip(lead,-W/2,-W/3);parts['leading_outer_right']=strip(lead,W/3,W/2)
  for key,piece in parts.items():
   v=area(piece);entry=q.setdefault(key,dict(area=0.,pressure=0.));entry['area']+=v;entry['pressure']+=v*f
 for group in ['middle','outer']:
  q['leading_'+group]={k:q['leading_'+group+'_left'][k]+q['leading_'+group+'_right'][k] for k in ['area','pressure']}
 assert abs(q['left']['area']-q['right']['area'])<1e-8
 assert abs(sum(q['leading_'+key]['pressure'] for key in ['centre','middle','outer'])-q['leading']['pressure'])<1e-10
 assert all(abs(q['leading_'+key]['area']-q['leading']['area']/3)<1e-8 for key in ['centre','middle','outer'])
 rows.append(dict(run=name,mesh_sha256=r['mesh_sha256'],loads=q));print(name,q,flush=True)
(b/'span_loads.json').write_text(json.dumps(dict(method='Exact polygon clipping at first40mm in x, then y=0 and equal-width span thirds. Piecewise-constant exported face pressure. Fixed outlet gauge.',rows=rows),indent=2)+'\n')
