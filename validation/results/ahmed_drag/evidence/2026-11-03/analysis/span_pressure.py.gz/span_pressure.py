"""Read restricted Cp locally; export only own comparison aggregates."""
import json,pathlib,sys
import numpy as np
root=pathlib.Path(__file__).resolve().parents[2]
sys.path.insert(0,str(root/'tools/fsae_aero'));import report
sys.path.insert(0,str(root/'tools/ahmed_drag'));import analyze
b=root/'runs/ahmed_cause'
names=['pressure_urf05_L1','edge10_L1','edge5_L1','slant10_L1','shear15_L1_pressure05','shear10_L1_pressure05','wake20_L1_pressure05','shear15_wake25_L1_pressure05']
comparisons=[report.cp_compare(report.walls(b/n),35)[0] for n in names]
groups=[analyze.pressure_groups(c[1],35,c[5]) for c in comparisons]
common=np.logical_and.reduce([g['slant_leading_40mm']&(c[4]<.006) for c,g in zip(comparisons,groups)])
xyz=comparisons[0][1];ay=np.abs(xyz[:,1]);width=.389
masks={'central_third':ay<width/6,'middle_thirds':(ay>=width/6)&(ay<width/3),'outer_thirds':ay>=width/3}
rows=[]
for name,c in zip(names,comparisons):
 for label,mask in masks.items():
  keep=common&mask;ref=c[2][keep];own=c[3][keep]
  rows.append(dict(run=name,span_bin=label,points=int(keep.sum()),reference_mean=float(ref.mean()) if len(ref) else None,kutta_mean=float(own.mean()) if len(ref) else None,rms=float(np.sqrt(np.mean((own-ref)**2))) if len(ref) else None))
(b/'span_pressure.json').write_text(json.dumps(dict(method='Common supported experimental leading-40mm taps; bins use absolute y at W/6 and W/3 with W=0.389m. No tap coordinates or curves exported.',rows=rows),indent=2)+'\n')
print(json.dumps(rows),flush=True)
